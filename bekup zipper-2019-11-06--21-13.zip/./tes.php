<?php

$servername = "localhost";
$username = "id11473405_kevin2d";
$password = "opik7295";
$database = "id11473405_kevin2d	";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
