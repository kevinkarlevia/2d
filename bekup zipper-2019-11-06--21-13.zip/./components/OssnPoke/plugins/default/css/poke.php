.ossn-notification-icon-poke,
.ossn-notification-icon-poke:before {
    display: inline-block;	
}
.ossn-notification-icon-poke:before {
	content: "\f0a4";
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    font-size: 18px;
}