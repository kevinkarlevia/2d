OssnEmbed
==========

Convert videos links to players. And convert simple links to html tag.

Supports:

* Youtube
* Google videos
* Vimeo
* Metacafe
* Veoh
* Dailymotion
* BlipTv
* Teachertube
* Hulu

3rd party libraries used in this component

* Linkify (c) 2010 Jeff Roberson - http://jmrware.com MIT-LICENSE
* VideoEmbed Copyright Cash Costello 2009-2011 GNU Public License version 2

