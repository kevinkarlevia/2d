OssnSmilies
===========

Will make a set of more than 1000 unicode emojis available for inserting at various places of your site.

With 'backward compatibility' enabled the following list of ascii patterns will be converted to smileys.

Supports:

:(
:)
=D
;)
:p
8|
o.O
:O
:*
a:
:h:
3:|
u:
:v
g:
8)
c:

